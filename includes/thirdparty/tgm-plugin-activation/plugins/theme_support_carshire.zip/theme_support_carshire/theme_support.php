<?php
/*
Plugin Name: Theme Support
Plugin URI: http://themeforest.net/user/template_path
Description: This plugin is compatible with carshire wordpress themes. 
Author: Muhibbur Rashid
Author URI: http://themebunch.com
Version: 1.0
Text Domain: BUNCH_NAME
*/
if( !defined( 'BUNCH_TH_ROOT' ) ) define('BUNCH_TH_ROOT', plugin_dir_path( __FILE__ ));
if( !defined( 'BUNCH_TH_URL' ) ) define( 'BUNCH_TH_URL', plugins_url( '', __FILE__ ) );
if( !defined( 'BUNCH_NAME' ) ) define( 'BUNCH_NAME', 'wp_carshire' );
include_once( 'includes/loader.php' );


function carshire_bunch_widget_init2()
{
	global $wp_registered_sidebars;
	$theme_options = _WSH()->option();
	if( class_exists( 'Bunch_Latest_Comments' ) )register_widget( 'Bunch_Latest_Comments' );
	if( class_exists( 'Bunch_Recent_Post_With_Image' ) )register_widget( 'Bunch_Recent_Post_With_Image' );
	if( class_exists( 'Bunch_Contact_Info_Sidebar' ) )register_widget( 'Bunch_Contact_Info_Sidebar' );
	if( class_exists( 'Bunch_Contact_Info' ) )register_widget( 'Bunch_Contact_Info' );
	if( class_exists( 'Bunch_Services_Posts' ) )register_widget( 'Bunch_Services_Posts' );
	if( class_exists( 'Bunch_Faqs_Posts' ) )register_widget( 'Bunch_Faqs_Posts' );
	if( class_exists( 'Bunch_Contactform' ) )register_widget( 'Bunch_Contactform' );
}
add_action( 'widgets_init', 'carshire_bunch_widget_init2' );